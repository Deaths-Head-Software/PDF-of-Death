When loading PDF's underlined text will not be displayed.
The underlines can be added back in the app itself.
sudo apt install tesseract-ocr ghostscript poppler-utils
