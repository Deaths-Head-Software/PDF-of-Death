from __future__ import annotations
import sys
import os
import time
import io
import subprocess
from pathlib import Path

from PyQt6.QtCore import Qt, QUrl, QSizeF
from PyQt6.QtGui import (
    QFont, QColor, QPalette, QPixmap, QPainter, QFontDatabase, 
    QTextCursor, QImage, QPdfWriter, QPageLayout, QPageSize, QAction,
    QTextDocument, QDesktopServices, QKeySequence, QIcon,
    QTextCharFormat, QTextBlockFormat, QTextImageFormat
)
import re
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QFileDialog, QMessageBox, QTextEdit,
    QListWidget, QSpinBox, QLineEdit, QTabWidget, QGroupBox,
    QComboBox, QSplashScreen, QColorDialog, QInputDialog, QMenu,
    QDialog, QDialogButtonBox, QCheckBox, QGridLayout, QPlainTextEdit
)

try:
    import pymupdf as fitz
except ImportError:
    try:
        import fitz
    except ImportError:
        fitz = None

try:
    from PIL import Image
    from pypdf import PdfReader, PdfWriter
    from reportlab.pdfgen import canvas
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.utils import ImageReader
    from docx import Document
    import markdown
    LIBS_AVAILABLE = True
except ImportError:
    LIBS_AVAILABLE = False

try:
    import pytesseract
except ImportError:
    pytesseract = None

APP_NAME = "PDF of Death"
ORG_NAME = "Death's Head Software"


def create_splash():
    """Create splash screen"""
    try:
        # Search for splash.png in multiple locations
        splash_path = None
        candidates = []

        if getattr(sys, 'frozen', False):
            candidates.append(Path(sys._MEIPASS) / "splash.png")
            candidates.append(Path(sys.executable).parent / "splash.png")
        else:
            candidates.append(Path(__file__).parent / "splash.png")
            candidates.append(Path(os.path.abspath(__file__)).parent / "splash.png")
            candidates.append(Path(os.getcwd()) / "splash.png")
            candidates.append(Path(os.path.abspath(sys.argv[0])).parent / "splash.png")

        for c in candidates:
            if c.exists():
                splash_path = c
                break

        if not splash_path:
            # Show which paths were checked so the user can diagnose
            checked = "\n".join(str(c) for c in candidates)
            try:
                from PyQt6.QtWidgets import QMessageBox
                QMessageBox.warning(None, "splash.png Not Found",
                    f"Could not find splash.png. Checked:\n\n{checked}\n\n"
                    f"Place splash.png in one of these locations.")
            except Exception:
                pass

        for c in candidates:
            if c.exists():
                splash_path = c
                break

        if splash_path:
            pixmap = QPixmap(str(splash_path))
            if pixmap.isNull():
                pixmap = QPixmap(800, 600)
                pixmap.fill(QColor(20, 20, 20))
            if pixmap.width() != 800 or pixmap.height() != 600:
                pixmap = pixmap.scaled(800, 600, Qt.AspectRatioMode.KeepAspectRatio,
                                       Qt.TransformationMode.SmoothTransformation)
            painter = QPainter(pixmap)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
            text_rect = pixmap.rect(); text_rect.setTop(40); text_rect.setBottom(100)
            painter.drawText(text_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)
            painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
            footer_rect = pixmap.rect(); footer_rect.setTop(pixmap.height() - 100); footer_rect.setBottom(pixmap.height() - 50)
            painter.drawText(footer_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)
            painter.end()
        else:
            # Fallback: generate dark screen with ASCII skull art
            pixmap = QPixmap(800, 600)
            pixmap.fill(QColor(20, 20, 20))
            painter = QPainter(pixmap)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
            text_rect = pixmap.rect(); text_rect.setTop(40); text_rect.setBottom(100)
            painter.drawText(text_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)
            painter.setFont(QFont("Courier", 14))
            skull_art = [
                "        ___________      ",
                "       /           \\    ",
                "      |  O       O  |   ",
                "      |      ^      |   ",
                "      |   \\_____/   |   ",
                "       \\_         _/    ",
                "         |_______|      ",
            ]
            y_start = 250
            for i, line in enumerate(skull_art):
                painter.drawText(250, y_start + (i * 25), line)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
            footer_rect = pixmap.rect(); footer_rect.setTop(pixmap.height() - 50); footer_rect.setBottom(pixmap.height())
            painter.drawText(footer_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)
            painter.end()

        return QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)
    except Exception as e:
        # Show error in a basic message box so it's visible
        try:
            from PyQt6.QtWidgets import QMessageBox
            QMessageBox.critical(None, "Splash Error", f"Splash failed: {type(e).__name__}: {e}")
        except Exception:
            pass
        return None


class PDFEditorApp(QMainWindow):
    """Main PDF Editor Application"""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("PDF of Death -  PDF Editor - Untitled")
        self.setGeometry(100, 100, 1200, 800)
        
        # Set window icon - works for both dev and PyInstaller
        if getattr(sys, 'frozen', False):
            icon_path = Path(sys._MEIPASS) / "icon.ico"
        else:
            icon_path = Path(__file__).parent / "icon.ico"
        
        if icon_path.exists():
            self.setWindowIcon(QIcon(str(icon_path)))
        
        self.set_light_theme()
        self.current_text_color = QColor(0, 0, 0)
        self.current_file_path = None
        self.last_search_term = ""
        self.last_directory = os.path.expanduser("~")  # Start with user's home directory
        self.init_ui()
    
    def closeEvent(self, event):
        """Clean up temp directory when app closes"""
        import tempfile
        import shutil
        temp_dir = os.path.join(tempfile.gettempdir(), "pdf_of_death_temp")
        if os.path.exists(temp_dir):
            try:
                shutil.rmtree(temp_dir)
            except:
                pass  # Ignore errors on cleanup
        event.accept()
        
    def set_light_theme(self):
        """Apply light color scheme"""
        palette = QPalette()
        palette.setColor(QPalette.ColorRole.Window, QColor(245, 245, 245))
        palette.setColor(QPalette.ColorRole.WindowText, QColor(0, 0, 0))
        palette.setColor(QPalette.ColorRole.Base, QColor(255, 255, 255))
        palette.setColor(QPalette.ColorRole.Button, QColor(230, 230, 230))
        palette.setColor(QPalette.ColorRole.ButtonText, QColor(0, 0, 0))
        palette.setColor(QPalette.ColorRole.Highlight, QColor(0, 120, 215))
        palette.setColor(QPalette.ColorRole.HighlightedText, QColor(255, 255, 255))
        self.setPalette(palette)
        
    def init_ui(self):
        """Initialize the user interface"""
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        main_layout = QVBoxLayout(central_widget)
        
        # Title
        title = QLabel("PDF of Death")
        title.setFont(QFont("Courier", 24, QFont.Weight.Bold))
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        main_layout.addWidget(title)
        
        subtitle = QLabel("Death's Head Software -  PDF Editor")
        subtitle.setFont(QFont("Courier", 10))
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        main_layout.addWidget(subtitle)
        
        # Create tabs
        self.tabs = QTabWidget()
        main_layout.addWidget(self.tabs)
        
        # Add tabs (removed Compress, Edit PDF, and Create PDF)
        self.add_text_editor_tab()
        self.add_convert_tab()
        self.add_merge_split_tab()
        self.add_security_tab()
        self.add_compress_tab()
        self.add_ocr_tab()
        self.add_text_convert_tab()
        
        # Status bar
        self.status_label = QLabel("Ready")
        main_layout.addWidget(self.status_label)
    
    def add_text_editor_tab(self):
        """Text editor with all system fonts, font color, and image insertion"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        # Toolbar
        toolbar = QHBoxLayout()
        
        btn_load = QPushButton("Load PDF")
        btn_load.clicked.connect(self.load_pdf_text)
        toolbar.addWidget(btn_load)
        
        btn_save = QPushButton("Save as PDF")
        btn_save.clicked.connect(self.save_text_as_pdf)
        toolbar.addWidget(btn_save)
        
        btn_close = QPushButton("Close PDF")
        btn_close.clicked.connect(self.close_pdf)
        toolbar.addWidget(btn_close)
        
        toolbar.addWidget(QLabel("|"))
        
        btn_cut = QPushButton("Cut")
        btn_cut.clicked.connect(lambda: self.text_editor.cut())
        toolbar.addWidget(btn_cut)
        
        btn_copy = QPushButton("Copy")
        btn_copy.clicked.connect(lambda: self.text_editor.copy())
        toolbar.addWidget(btn_copy)
        
        btn_paste = QPushButton("Paste")
        btn_paste.clicked.connect(lambda: self.text_editor.paste())
        toolbar.addWidget(btn_paste)
        
        btn_select_all = QPushButton("Select All")
        btn_select_all.clicked.connect(lambda: self.text_editor.selectAll())
        toolbar.addWidget(btn_select_all)
        
        toolbar.addWidget(QLabel("|"))
        
        btn_undo = QPushButton("Undo")
        btn_undo.clicked.connect(lambda: self.text_editor.undo())
        toolbar.addWidget(btn_undo)
        
        btn_redo = QPushButton("Redo")
        btn_redo.clicked.connect(lambda: self.text_editor.redo())
        toolbar.addWidget(btn_redo)
        
        toolbar.addStretch()
        layout.addLayout(toolbar)
        
        # Font controls
        font_bar = QHBoxLayout()
        
        font_bar.addWidget(QLabel("Font:"))
        self.font_family = QComboBox()
        # Get all system fonts
        system_fonts = QFontDatabase.families()
        self.font_family.addItems(system_fonts)
        # Set default to Courier if available
        arial_index = self.font_family.findText("Courier")
        if arial_index >= 0:
            self.font_family.setCurrentIndex(arial_index)
        self.font_family.currentTextChanged.connect(self.change_font)
        font_bar.addWidget(self.font_family)
        
        font_bar.addWidget(QLabel("Size:"))
        self.font_size = QSpinBox()
        self.font_size.setRange(6, 72)
        self.font_size.setValue(12)
        self.font_size.valueChanged.connect(self.change_font)
        font_bar.addWidget(self.font_size)
        
        self.btn_bold = QPushButton("Bold")
        self.btn_bold.setCheckable(True)
        self.btn_bold.clicked.connect(self.toggle_bold)
        font_bar.addWidget(self.btn_bold)
        
        self.btn_italic = QPushButton("Italic")
        self.btn_italic.setCheckable(True)
        self.btn_italic.clicked.connect(self.toggle_italic)
        font_bar.addWidget(self.btn_italic)
        
        self.btn_underline = QPushButton("Underline")
        self.btn_underline.setCheckable(True)
        self.btn_underline.clicked.connect(self.toggle_underline)
        font_bar.addWidget(self.btn_underline)
        
        font_bar.addWidget(QLabel("|"))
        
        # Alignment buttons
        btn_align_left = QPushButton("Left")
        btn_align_left.clicked.connect(lambda: self.set_alignment(Qt.AlignmentFlag.AlignLeft))
        font_bar.addWidget(btn_align_left)
        
        btn_align_center = QPushButton("Center")
        btn_align_center.clicked.connect(lambda: self.set_alignment(Qt.AlignmentFlag.AlignCenter))
        font_bar.addWidget(btn_align_center)
        
        btn_align_right = QPushButton("Right")
        btn_align_right.clicked.connect(lambda: self.set_alignment(Qt.AlignmentFlag.AlignRight))
        font_bar.addWidget(btn_align_right)

        font_bar.addWidget(QLabel("|"))
        
        # Font color button
        self.btn_color = QPushButton("Font Color")
        self.btn_color.clicked.connect(self.choose_font_color)
        self.btn_color.setStyleSheet("background-color: black; color: white;")
        font_bar.addWidget(self.btn_color)
        
        font_bar.addWidget(QLabel("|"))
        
        # Insert image button
        btn_insert_image = QPushButton("Insert Image")
        btn_insert_image.clicked.connect(self.insert_image)
        font_bar.addWidget(btn_insert_image)
        
        font_bar.addWidget(QLabel("|"))
        
        btn_find = QPushButton("Find")
        btn_find.clicked.connect(self.find_text)
        font_bar.addWidget(btn_find)
        
        btn_replace = QPushButton("Replace")
        btn_replace.clicked.connect(self.replace_text)
        font_bar.addWidget(btn_replace)
        
        font_bar.addStretch()
        layout.addLayout(font_bar)
        
        # Text editor
        self.text_editor = QTextEdit()
        self.text_editor.setAcceptRichText(True)
        self.text_editor.setFont(QFont("Courier", 12))
        self.text_editor.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.text_editor.customContextMenuRequested.connect(self.show_context_menu)
        
        # F3 shortcut for Find Next
        find_next_action = QAction(self)
        find_next_action.setShortcut(QKeySequence("F3"))
        find_next_action.triggered.connect(self.find_next)
        self.addAction(find_next_action)

        self.text_editor.setPlaceholderText(
            "Load a PDF to edit its text, or start typing to create a new PDF...\n\n"
            "Features: Cut, Copy, Paste, All System Fonts, Font Color, Insert Images, Find & Replace"
        )
        layout.addWidget(self.text_editor)
        
        self.tabs.addTab(tab, "Text Editor")
    
    def add_convert_tab(self):
        """Conversion features"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        # Image to PDF
        img_group = QGroupBox("Image ↔ PDF")
        img_layout = QVBoxLayout(img_group)
        
        btn_img_to_pdf = QPushButton("Images → PDF")
        btn_img_to_pdf.clicked.connect(self.images_to_pdf)
        img_layout.addWidget(btn_img_to_pdf)
        
        btn_pdf_to_img = QPushButton("PDF → Images (PNG/JPG)")
        btn_pdf_to_img.clicked.connect(self.pdf_to_images)
        img_layout.addWidget(btn_pdf_to_img)
        
        layout.addWidget(img_group)
        
        # Word conversion
        word_group = QGroupBox("Word ↔ PDF")
        word_layout = QVBoxLayout(word_group)
        
        btn_word_to_pdf = QPushButton("Word → PDF")
        btn_word_to_pdf.clicked.connect(self.word_to_pdf)
        word_layout.addWidget(btn_word_to_pdf)
        
        btn_pdf_to_word = QPushButton("PDF → Word")
        btn_pdf_to_word.clicked.connect(self.pdf_to_word)
        word_layout.addWidget(btn_pdf_to_word)
        
        layout.addWidget(word_group)
        
       
        
        # TXT/MD to PDF
        text_group = QGroupBox("Text → PDF")
        text_layout = QVBoxLayout(text_group)
        
        btn_txt_to_pdf = QPushButton("TXT → PDF")
        btn_txt_to_pdf.clicked.connect(self.txt_to_pdf)
        text_layout.addWidget(btn_txt_to_pdf)
        
        btn_md_to_pdf = QPushButton("Markdown → PDF")
        btn_md_to_pdf.clicked.connect(self.md_to_pdf)
        text_layout.addWidget(btn_md_to_pdf)
        
        layout.addWidget(text_group)
        
        layout.addStretch()
        self.tabs.addTab(tab, "Convert")
    
    def add_merge_split_tab(self):
        """Merge/split PDFs"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        merge_group = QGroupBox("Merge PDFs")
        merge_layout = QVBoxLayout(merge_group)
        
        self.merge_list = QListWidget()
        merge_layout.addWidget(QLabel("Selected PDFs:"))
        merge_layout.addWidget(self.merge_list)
        
        btn_add = QPushButton("Add PDFs")
        btn_add.clicked.connect(self.add_pdfs_to_merge)
        merge_layout.addWidget(btn_add)
        
        btn_merge = QPushButton("Merge All PDFs")
        btn_merge.clicked.connect(self.merge_pdfs)
        merge_layout.addWidget(btn_merge)
        
        layout.addWidget(merge_group)
        
        # Split PDF
        split_group = QGroupBox("Split PDF")
        split_layout = QVBoxLayout(split_group)
        
        split_layout.addWidget(QLabel("Split by page range or every page"))
        
        btn_split_all = QPushButton("Split PDF (Every Page)")
        btn_split_all.clicked.connect(self.split_pdf_all)
        split_layout.addWidget(btn_split_all)
        
        btn_split_range = QPushButton("Split PDF (Page Range)")
        btn_split_range.clicked.connect(self.split_pdf_range)
        split_layout.addWidget(btn_split_range)
        
        layout.addWidget(split_group)
        
        layout.addStretch()
        self.tabs.addTab(tab, "Merge/Split")
    
    def add_security_tab(self):
        """Password protect and unlock PDFs"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        protect_group = QGroupBox("Password Protection")
        protect_layout = QVBoxLayout(protect_group)
        
        protect_layout.addWidget(QLabel("Password:"))
        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)
        protect_layout.addWidget(self.password_input)
        
        btn_protect = QPushButton("Protect PDF with Password")
        btn_protect.clicked.connect(self.protect_pdf)
        protect_layout.addWidget(btn_protect)
        
        layout.addWidget(protect_group)
        
        unlock_group = QGroupBox("Unlock PDF")
        unlock_layout = QVBoxLayout(unlock_group)
        
        unlock_layout.addWidget(QLabel("Password:"))
        self.unlock_password_input = QLineEdit()
        self.unlock_password_input.setEchoMode(QLineEdit.EchoMode.Password)
        unlock_layout.addWidget(self.unlock_password_input)
        
        btn_unlock = QPushButton("Unlock PDF")
        btn_unlock.clicked.connect(self.unlock_pdf)
        unlock_layout.addWidget(btn_unlock)
        
        layout.addWidget(unlock_group)
        
        layout.addStretch()
        self.tabs.addTab(tab, "Security")
    
    def add_compress_tab(self):
        """PDF Compression with different levels"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        compress_group = QGroupBox("PDF Compression")
        compress_layout = QVBoxLayout(compress_group)
        
        compress_layout.addWidget(QLabel("Select a compression level and choose a PDF to compress:"))
        compress_layout.addWidget(QLabel(""))
        
        # Compression level selection
        compress_layout.addWidget(QLabel("Compression Level:"))
        self.compression_level = QComboBox()
        self.compression_level.addItems([
            "Low - Gentle compression (largest file)",
            "Medium - Balanced compression (recommended)",
            "High - Maximum compression (smallest file)"
        ])
        self.compression_level.setCurrentIndex(1)  # Default to Medium
        compress_layout.addWidget(self.compression_level)
        
        compress_layout.addWidget(QLabel(""))
        
        # Compression info
        info_label = QLabel(
            "Low: Preserves maximum quality, minimal file size reduction\n"
            "Medium: Good balance between quality and file size\n"
            "High: Aggressive compression for smallest files"
        )
        info_label.setWordWrap(True)
        info_label.setStyleSheet("color: gray; font-size: 9pt;")
        compress_layout.addWidget(info_label)
        
        compress_layout.addWidget(QLabel(""))
        
        btn_compress = QPushButton("Compress PDF")
        btn_compress.clicked.connect(self.compress_pdf)
        compress_layout.addWidget(btn_compress)
        
        layout.addWidget(compress_group)
        
        layout.addStretch()
        self.tabs.addTab(tab, "Compress")
    
  
    
    def add_ocr_tab(self):
        """OCR - Extract text from images and scanned PDFs"""
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # --- Input group ---
        input_group = QGroupBox("Extract Text")
        input_layout = QVBoxLayout(input_group)

        input_layout.addWidget(QLabel("Extract text from an image or a scanned PDF using OCR:"))
        input_layout.addWidget(QLabel(""))

        btn_row = QHBoxLayout()

        btn_ocr_image = QPushButton("OCR Image")
        btn_ocr_image.setToolTip("Extract text from PNG, JPG, BMP, TIFF")
        btn_ocr_image.clicked.connect(self.ocr_image)
        btn_row.addWidget(btn_ocr_image)

        btn_ocr_pdf = QPushButton("OCR PDF")
        btn_ocr_pdf.setToolTip("Extract text from a scanned PDF")
        btn_ocr_pdf.clicked.connect(self.ocr_pdf)
        btn_row.addWidget(btn_ocr_pdf)

        input_layout.addLayout(btn_row)
        layout.addWidget(input_group)

        # --- Output group ---
        output_group = QGroupBox("Extracted Text")
        output_layout = QVBoxLayout(output_group)

        self.ocr_output = QPlainTextEdit()
        self.ocr_output.setPlaceholderText("Extracted text will appear here...")
        self.ocr_output.setFont(QFont("Courier", 10))
        output_layout.addWidget(self.ocr_output)

        btn_row2 = QHBoxLayout()

        btn_copy = QPushButton("Copy to Clipboard")
        btn_copy.clicked.connect(lambda: QApplication.clipboard().setText(self.ocr_output.toPlainText()))
        btn_row2.addWidget(btn_copy)

        btn_clear = QPushButton("Clear")
        btn_clear.clicked.connect(self.ocr_output.clear)
        btn_row2.addWidget(btn_clear)

        btn_save = QPushButton("Save as TXT")
        btn_save.clicked.connect(self.save_extracted_text)
        btn_row2.addWidget(btn_save)

        output_layout.addLayout(btn_row2)
        layout.addWidget(output_group)

        self.tabs.addTab(tab, "OCR")

    def add_text_convert_tab(self):
        """Convert between text file formats"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        convert_group = QGroupBox("Text File Converter")
        convert_layout = QVBoxLayout(convert_group)
        
        convert_layout.addWidget(QLabel("Convert between: TXT, MD, HTML, CSV, JSON, XML"))
        
        format_layout = QHBoxLayout()
        format_layout.addWidget(QLabel("From:"))
        self.from_format = QComboBox()
        self.from_format.addItems(["TXT", "MD", "HTML", "CSV", "JSON", "XML"])
        format_layout.addWidget(self.from_format)
        
        format_layout.addWidget(QLabel("To:"))
        self.to_format = QComboBox()
        self.to_format.addItems(["TXT", "MD", "HTML", "CSV", "JSON", "XML"])
        format_layout.addWidget(self.to_format)
        
        convert_layout.addLayout(format_layout)
        
        btn_convert_text = QPushButton("Convert Text File")
        btn_convert_text.clicked.connect(self.convert_text_file)
        convert_layout.addWidget(btn_convert_text)
        
        layout.addWidget(convert_group)
        
        layout.addStretch()
        self.tabs.addTab(tab, "Text Convert")
    
    # Text Editor Methods
    
    def load_pdf_text(self):
        """Load PDF text and images"""
        pdf_file, _ = QFileDialog.getOpenFileName(self, "Select PDF", self.last_directory, "PDF Files (*.pdf)")
        if not pdf_file:
            return
        
        # Remember the directory for next time
        self.last_directory = os.path.dirname(pdf_file)
            
        self.text_editor.clear()
        self.current_file_path = pdf_file
        self.setWindowTitle(f"PDF of Death - {os.path.basename(pdf_file)}")
        
        # Use system temp directory instead of creating folders next to PDF
        import tempfile
        import shutil
        temp_dir = os.path.join(tempfile.gettempdir(), "pdf_of_death_temp")
        
        # Clean up old temp directory if it exists
        if os.path.exists(temp_dir):
            try:
                shutil.rmtree(temp_dir)
            except:
                pass  # If cleanup fails, continue anyway
        
        # Create fresh temp directory
        os.makedirs(temp_dir, exist_ok=True)
        
        cursor = self.text_editor.textCursor()
        
        # Try PyMuPDF (fitz) first
        if fitz:
            try:
                doc = fitz.open(pdf_file)
                for i, page in enumerate(doc):
                    # Get text and images as blocks
                    # sort=True ensures visual reading order (top-down, left-right)
                    blocks = page.get_text("dict", sort=True)["blocks"]
                    
                    # Track previous block's bottom position to detect gaps
                    prev_block_bottom = 0
                    
                    for block_idx, block in enumerate(blocks):
                        if block["type"] == 0:
                            page_height = page.rect.height
                            page_width = page.rect.width
                            x0, y0, x1, y1 = block["bbox"]
                            y_center = (y0 + y1) / 2
                            x_center = (x0 + x1) / 2
                            
                            # Detect vertical gap between blocks (indicates blank lines)
                            if prev_block_bottom > 0:
                                gap = y0 - prev_block_bottom
                                # Get approximate line height from first span in block
                                avg_line_height = 12  # default
                                if block.get("lines") and len(block["lines"]) > 0:
                                    first_line = block["lines"][0]
                                    if first_line.get("spans") and len(first_line["spans"]) > 0:
                                        font_size = first_line["spans"][0].get("size", 12)
                                        avg_line_height = font_size * 1.2  # typical line spacing
                                
                                # Smart blank line detection:
                                # - Ignore tiny gaps (< 0.5x line height) - these are normal line spacing
                                # - Gaps around 1x line height = paragraph break = 1 blank line
                                # - Larger gaps = multiple blank lines
                                if gap > avg_line_height * 0.5:  # Ignore tiny gaps
                                    if gap < avg_line_height * 1.5:
                                        # Gap is close to 1x line height = single blank line
                                        cursor.insertBlock()
                                    else:
                                        # Larger gap = multiple blank lines
                                        num_blank_lines = int(gap / avg_line_height)
                                        for _ in range(min(num_blank_lines, 5)):
                                            cursor.insertBlock()
                            
                            prev_block_bottom = y1
                            
                            is_header_footer_area = (y_center < page_height * 0.1 or y_center > page_height * 0.9)
                            block_text_all = []
                            for line in block["lines"]:
                                line_text = "".join(span["text"] + " " for span in line["spans"]).strip()
                                if line_text:
                                    block_text_all.append(line_text)
                            clean_text = " ".join(block_text_all).strip()
                            is_page_num = False
                            if (re.match(r'^\d+$', clean_text) or
                                re.match(r'^Page \\d+$', clean_text, re.IGNORECASE) or
                                re.match(r'^Page \\d+ of \\d+$', clean_text, re.IGNORECASE) or
                                re.match(r'^\\d+ of \\d+$', clean_text, re.IGNORECASE) or
                                re.match(r'^-\\s*\\d+\\s*-$', clean_text)):
                                if is_header_footer_area:
                                    is_page_num = True
                            if is_page_num:
                                continue
                            page_width = page.rect.width
                            align = Qt.AlignmentFlag.AlignLeft
                            if abs(x_center - (page_width / 2)) < (page_width * 0.1):
                                align = Qt.AlignmentFlag.AlignCenter
                            elif (page_width - x1) < (page_width * 0.1):
                                align = Qt.AlignmentFlag.AlignRight
                            block_fmt = QTextBlockFormat()
                            block_fmt.setAlignment(align)
                            
                            # Track if we inserted any content for this block
                            block_has_content = False
                            
                            for line in block["lines"]:
                                cursor.insertBlock(block_fmt)
                                
                                # Check if line has any text
                                line_has_text = False
                                for span in line["spans"]:
                                    txt = span.get("text", "")
                                    if txt.strip():  # Has non-whitespace text
                                        line_has_text = True
                                        block_has_content = True
                                        
                                        # Create character format with all formatting
                                        fmt = QTextCharFormat()
                                        
                                        # Font family and detect bold/italic from font name
                                        font_name = span.get("font", "")
                                        is_bold = False
                                        is_italic = False
                                        
                                        if font_name:
                                            font_lower = font_name.lower()
                                            
                                            # Check for standard bold indicators
                                            if any(x in font_lower for x in ["bold", "-bold", "bd", "-bd", "heavy", "black"]):
                                                is_bold = True
                                            
                                            # Check for weight number (e.g., Tahoma-1-700)
                                            parts = font_name.split('-')
                                            if len(parts) >= 3:
                                                try:
                                                    if parts[-2] == '1':
                                                        is_italic = True
                                                    weight = int(parts[-1])
                                                    if weight >= 600:
                                                        is_bold = True
                                                except (ValueError, IndexError):
                                                    pass
                                            
                                            # Check for standard italic indicators
                                            if any(x in font_lower for x in ["italic", "-italic", "oblique", "-oblique", "it", "-it", "ital"]):
                                                is_italic = True
                                            
                                            # Extract base font name
                                            base_font = font_name
                                            base_font = re.sub(r'-\d+-\d+$', '', base_font)
                                            for suffix in ["-Bold", "-Italic", "-BoldItalic", "-BoldOblique", 
                                                          "Bold", "Italic", "BoldItalic", "-It", "-Bd",
                                                          "Oblique", "-Oblique"]:
                                                base_font = base_font.replace(suffix, "")
                                            base_font = base_font.strip()
                                            
                                            if base_font:
                                                fmt.setFontFamily(base_font)
                                        
                                        # Font size
                                        size = span.get("size")
                                        if size:
                                            try:
                                                fmt.setFontPointSize(float(size))
                                            except Exception:
                                                pass
                                        
                                        # Color
                                        color = span.get("color")
                                        if color is not None:
                                            try:
                                                if isinstance(color, int):
                                                    r = (color >> 16) & 0xFF
                                                    g = (color >> 8) & 0xFF
                                                    b = color & 0xFF
                                                    fmt.setForeground(QColor(r, g, b))
                                                elif isinstance(color, (tuple, list)) and len(color) >= 3:
                                                    r, g, b = color[:3]
                                                    r = int(r * 255) if isinstance(r, float) and r <= 1 else int(r)
                                                    g = int(g * 255) if isinstance(g, float) and g <= 1 else int(g)
                                                    b = int(b * 255) if isinstance(b, float) and b <= 1 else int(b)
                                                    fmt.setForeground(QColor(r, g, b))
                                            except Exception:
                                                pass
                                        
                                        # Apply bold/italic from flags as backup
                                        flags = span.get("flags", 0)
                                        if isinstance(flags, int):
                                            if flags & 16:
                                                is_bold = True
                                            if flags & 2:
                                                is_italic = True
                                        
                                        if is_bold:
                                            fmt.setFontWeight(QFont.Weight.Bold)
                                        if is_italic:
                                            fmt.setFontItalic(True)
                                        
                                        # Apply format and insert text
                                        cursor.setCharFormat(fmt)
                                        cursor.insertText(txt)
                                
                                # If line had no text, it's a blank line - preserve it
                                if not line_has_text:
                                    # Insert empty text to preserve the blank line
                                    cursor.insertText("")
                                
                        elif block["type"] == 1: # Image
                            try:
                                image_data = block["image"]
                                ext = block.get("ext", "png")
                                image_filename = f"page_{i+1}_img_{int(time.time()*1000)}.{ext}"
                                image_path = os.path.join(temp_dir, image_filename)
                                
                                with open(image_path, "wb") as f:
                                    f.write(image_data)
                                
                                # Determine alignment
                                page_width = page.rect.width
                                bbox = block.get("bbox")
                                align = Qt.AlignmentFlag.AlignCenter
                                if isinstance(bbox, (list, tuple)) and len(bbox) == 4:
                                    ix0, iy0, ix1, iy1 = bbox
                                    img_center_x = (ix0 + ix1) / 2
                                    if abs(img_center_x - (page_width / 2)) > (page_width * 0.1):
                                        if img_center_x < (page_width / 2):
                                            align = Qt.AlignmentFlag.AlignLeft
                                        else:
                                            align = Qt.AlignmentFlag.AlignRight
                                
                                # Insert on new line with alignment
                                block_fmt = QTextBlockFormat()
                                block_fmt.setAlignment(align)
                                cursor.insertBlock(block_fmt)
                                
                                # Insert image
                                img_fmt = QTextImageFormat()
                                img_fmt.setName(image_path)
                                cursor.insertImage(img_fmt)
                            except Exception as img_err:
                                # Silently skip problematic images
                                pass
                
                self.status_label.setText(f"Loaded with PyMuPDF: {pdf_file}")
                return
            except Exception as e:
                # Silently fall back to pypdf if PyMuPDF fails
                self.text_editor.clear()
                cursor = self.text_editor.textCursor()

        try:
            reader = PdfReader(pdf_file)
            
            for i, page in enumerate(reader.pages):
                # Text extraction
                page_text = page.extract_text()
                if not page_text:
                     continue
                
                # Clean page numbers and footers (safer heuristic)
                lines = page_text.split('\n')
                cleaned_lines = []
                for idx, line in enumerate(lines):
                    clean_line = line.strip()
                    is_page_num = False
                    
                    # Check regex patterns
                    if (re.match(r'^\d+$', clean_line) or
                        re.match(r'^Page \d+$', clean_line, re.IGNORECASE) or
                        re.match(r'^Page \d+ of \d+$', clean_line, re.IGNORECASE) or
                        re.match(r'^\d+ of \d+$', clean_line, re.IGNORECASE) or
                        re.match(r'^-\s*\d+\s*-$', clean_line)):
                        
                        # Only remove if at start or end of page content
                        # (Allowing a buffer of 3 lines for headers/footers)
                        if idx < 3 or idx > len(lines) - 4:
                            is_page_num = True
                    
                    if not is_page_num:
                        cleaned_lines.append(line)
                
                text_content = '\n'.join(cleaned_lines) + "\n"
                cursor.insertText(text_content)
                
                # Image extraction
                if hasattr(page, 'images'):
                    try:
                        for image_file_obj in page.images:
                            image_path = os.path.join(temp_dir, f"page_{i+1}_{image_file_obj.name}")
                            with open(image_path, "wb") as fp:
                                fp.write(image_file_obj.data)
                            
                            # Insert image
                            cursor.insertText("\n")
                            cursor.insertImage(image_path)
                            cursor.insertText("\n")
                    except Exception as img_e:
                        # Silently skip problematic images
                        pass
                
          
            
            self.status_label.setText(f"Loaded: {pdf_file}")
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to load PDF: {str(e)}")
    
    def save_text_as_pdf(self):
        """Save text as PDF maintaining formatting and images"""
        if self.text_editor.document().isEmpty():
            QMessageBox.warning(self, "Warning", "No content to save!")
            return
        
        output, _ = QFileDialog.getSaveFileName(self, "Save PDF", self.last_directory, "PDF Files (*.pdf)")
        if not output:
            return
        
        # Remember the directory for next time
        self.last_directory = os.path.dirname(output)
            
        try:
            printer = QPdfWriter(output)
            printer.setPageSize(QPageSize(QPageSize.PageSizeId.Letter))
            printer.setResolution(300)
            
            # Set margins
            layout = QPageLayout()
            layout.setPageSize(QPageSize(QPageSize.PageSizeId.Letter))
            layout.setOrientation(QPageLayout.Orientation.Portrait)
            printer.setPageLayout(layout)
            
            # Clone document to ensure correct layout for printing (fixes alignment issues)
            doc = self.text_editor.document().clone()
            doc.print(printer)
            
            self.status_label.setText(f"Saved: {output}")
            QMessageBox.information(self, "Success", "PDF saved successfully!")
            
            self.current_file_path = output
            self.setWindowTitle(f"PDF of Death - {os.path.basename(output)}")
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to save PDF: {str(e)}")
    
    def change_font(self):
        """Change font"""
        font = QFont(self.font_family.currentText(), self.font_size.value())
        
        if self.btn_bold.isChecked():
            font.setBold(True)
        if self.btn_italic.isChecked():
            font.setItalic(True)
        if self.btn_underline.isChecked():
            font.setUnderline(True)
        
        cursor = self.text_editor.textCursor()
        if cursor.hasSelection():
            fmt = cursor.charFormat()
            fmt.setFont(font)
            cursor.setCharFormat(fmt)
        else:
            self.text_editor.setCurrentFont(font)
            self.text_editor.setFontPointSize(self.font_size.value())
    
    def toggle_bold(self):
        font = self.text_editor.currentFont()
        font.setBold(self.btn_bold.isChecked())
        self.text_editor.setCurrentFont(font)
    
    def toggle_italic(self):
        font = self.text_editor.currentFont()
        font.setItalic(self.btn_italic.isChecked())
        self.text_editor.setCurrentFont(font)
    
    def toggle_underline(self):
        font = self.text_editor.currentFont()
        font.setUnderline(self.btn_underline.isChecked())
        self.text_editor.setCurrentFont(font)
        
    def set_alignment(self, alignment):
        """Set paragraph alignment"""
        self.text_editor.setAlignment(alignment)
    
    def choose_font_color(self):
        """Choose font color"""
        color = QColorDialog.getColor(self.current_text_color, self, "Choose Font Color")
        if color.isValid():
            self.current_text_color = color
            self.text_editor.setTextColor(color)
            r, g, b = color.red(), color.green(), color.blue()
            brightness = (r * 299 + g * 587 + b * 114) / 1000
            text_color = "white" if brightness < 128 else "black"
            self.btn_color.setStyleSheet(f"background-color: rgb({r}, {g}, {b}); color: {text_color};")
            self.status_label.setText(f"Font color: RGB({r}, {g}, {b})")
    
    def insert_image(self):
        """Insert image into text editor with resize option"""
        image_file, _ = QFileDialog.getOpenFileName(
            self, "Select Image", "", 
            "Images (*.png *.jpg *.jpeg *.bmp *.gif)"
        )
        if not image_file:
            return
        
        try:
            # Ask user for image size
            pixmap = QPixmap(image_file)
            original_width = pixmap.width()
            original_height = pixmap.height()
            
            # Ask for width
            width, ok = QInputDialog.getInt(
                self, "Image Size", 
                f"Enter image width in pixels\nOriginal: {original_width}x{original_height}",
                400, 50, 2000
            )
            if not ok:
                return
            
            # Calculate proportional height
            height = int((width / original_width) * original_height)
            
            # Resize image
            pixmap = pixmap.scaled(width, height, Qt.AspectRatioMode.KeepAspectRatio,
                                  Qt.TransformationMode.SmoothTransformation)
            
            # Save resized image to system temp directory
            import tempfile
            temp_dir = os.path.join(tempfile.gettempdir(), "pdf_of_death_temp")
            os.makedirs(temp_dir, exist_ok=True)
            temp_path = os.path.join(temp_dir, f"resized_{int(time.time()*1000)}_{os.path.basename(image_file)}")
            pixmap.save(temp_path)
            
            # Insert into text editor
            cursor = self.text_editor.textCursor()
            cursor.insertImage(temp_path)
            
            self.status_label.setText(f"Image inserted: {os.path.basename(image_file)} ({width}x{height})")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to insert image: {str(e)}")
    
    def close_pdf(self):
        """Close current PDF and reset editor"""
        self.text_editor.clear()
        self.current_file_path = None
        self.setWindowTitle("PDF of Death -  PDF Editor - Untitled")
        self.status_label.setText("Closed PDF")
        
    def find_text(self):
        """Find text with F3 support"""
        search_text, ok = QInputDialog.getText(self, "Find", "Enter text to find:", 
                                             text=self.last_search_term)
        if ok and search_text:
            self.last_search_term = search_text
            self.find_next()

    def find_next(self):
        """Find next occurrence"""
        if not self.last_search_term:
            self.find_text()
            return
            
        if self.text_editor.find(self.last_search_term):
            self.status_label.setText(f"Found: '{self.last_search_term}'")
        else:
            # Wrap around
            cursor = self.text_editor.textCursor()
            cursor.movePosition(QTextCursor.MoveOperation.Start)
            self.text_editor.setTextCursor(cursor)
            if self.text_editor.find(self.last_search_term):
                 self.status_label.setText(f"Found: '{self.last_search_term}' (wrapped)")
            else:
                QMessageBox.information(self, "Find", f"Text '{self.last_search_term}' not found")

    def replace_text(self):
        """Replace text with Undo support"""
        dialog = QDialog(self)
        dialog.setWindowTitle("Replace")
        layout = QGridLayout(dialog)
        
        layout.addWidget(QLabel("Find:"), 0, 0)
        find_input = QLineEdit(self.last_search_term)
        layout.addWidget(find_input, 0, 1)
        
        layout.addWidget(QLabel("Replace with:"), 1, 0)
        replace_input = QLineEdit()
        layout.addWidget(replace_input, 1, 1)
        
        btn_box = QDialogButtonBox()
        btn_replace = btn_box.addButton("Replace", QDialogButtonBox.ButtonRole.ActionRole)
        btn_replace_all = btn_box.addButton("Replace All", QDialogButtonBox.ButtonRole.ActionRole)
        btn_cancel = btn_box.addButton(QDialogButtonBox.StandardButton.Cancel)
        layout.addWidget(btn_box, 2, 0, 1, 2)
        
        btn_cancel.clicked.connect(dialog.reject)
        
        def do_replace():
            find_str = find_input.text()
            replace_str = replace_input.text()
            if not find_str:
                return
            
            self.last_search_term = find_str
            
            if self.text_editor.find(find_str):
                cursor = self.text_editor.textCursor()
                cursor.insertText(replace_str)
                self.status_label.setText("Replaced one occurrence")
            else:
                 QMessageBox.information(self, "Replace", f"'{find_str}' not found")
        
        def do_replace_all():
            find_str = find_input.text()
            replace_str = replace_input.text()
            if not find_str:
                return
            
            self.last_search_term = find_str
            
            
            
            cursor = self.text_editor.textCursor()
            cursor.movePosition(QTextCursor.MoveOperation.Start)
            self.text_editor.setTextCursor(cursor)
            
            count = 0
            while self.text_editor.find(find_str):
                cursor = self.text_editor.textCursor()
                cursor.insertText(replace_str)
                count += 1
            
                        
            if count > 0:
                self.status_label.setText(f"Replaced {count} occurrences")
            else:
                QMessageBox.information(self, "Replace", f"'{find_str}' not found")
            
            dialog.accept()

        btn_replace.clicked.connect(do_replace)
        btn_replace_all.clicked.connect(do_replace_all)
        
        dialog.exec()

    def show_context_menu(self, position):
        menu = self.text_editor.createStandardContextMenu()
        
        cursor = self.text_editor.cursorForPosition(position)
        fmt = cursor.charFormat()
        
        if fmt.isImageFormat():
            menu.addSeparator()
            resize_action = menu.addAction("Resize Image")
            delete_action = menu.addAction("Delete Image")
            
            action = menu.exec(self.text_editor.mapToGlobal(position))
            
            if action == resize_action:
                self.resize_image_at_cursor(cursor)
            elif action == delete_action:
                self.delete_image_at_cursor(cursor)
        else:
            menu.exec(self.text_editor.mapToGlobal(position))
            
    def resize_image_at_cursor(self, cursor):
        img_fmt = cursor.charFormat().toImageFormat()
        current_width = int(img_fmt.width() or 300)
        name = img_fmt.name()
        if not name:
            return
        width, ok = QInputDialog.getInt(
            self, "Resize Image",
            "Enter new width (px):",
            current_width, 10, 2000
        )
        if ok:
            new_fmt = QTextImageFormat()
            new_fmt.setName(name)
            new_fmt.setWidth(width)
            cursor.select(QTextCursor.SelectionType.WordUnderCursor)
            cursor.removeSelectedText()
            cursor.insertImage(new_fmt)

             
    def delete_image_at_cursor(self, cursor):
        cursor.select(QTextCursor.SelectionType.WordUnderCursor)
        cursor.removeSelectedText()

    
    # Conversion Methods
    
    def images_to_pdf(self):
        files, _ = QFileDialog.getOpenFileNames(self, "Select Images", "",
            "Images (*.png *.jpg *.jpeg *.bmp *.gif *.tiff)")
        if not files:
            return
        
        output, _ = QFileDialog.getSaveFileName(self, "Save PDF", "", "PDF Files (*.pdf)")
        if not output:
            return
        
        try:
            converted = []
            for f in files:
                img = Image.open(f)
                # Handle all modes that can't be saved to PDF directly
                if img.mode in ('RGBA', 'LA', 'P'):
                    background = Image.new('RGB', img.size, (255, 255, 255))
                    if img.mode == 'P':
                        img = img.convert('RGBA')
                    background.paste(img, mask=img.split()[-1] if img.mode in ('RGBA', 'LA') else None)
                    img = background
                elif img.mode != 'RGB':
                    img = img.convert('RGB')
                converted.append(img)

            converted[0].save(
                output,
                format='PDF',
                save_all=True,
                append_images=converted[1:]
            )
            self.status_label.setText(f"Saved: {output}")
            QMessageBox.information(self, "Success", f"Converted {len(converted)} image(s) to PDF!")
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))
    
    def pdf_to_images(self):
        pdf_file, _ = QFileDialog.getOpenFileName(self, "Select PDF", "", "PDF Files (*.pdf)")
        if not pdf_file:
            return
        
        output_dir = QFileDialog.getExistingDirectory(self, "Select Output Directory")
        if not output_dir:
            return
        
        try:
            from pdf2image import convert_from_path
            # Suppress console window on Windows
            hide_kwargs = {}
            if sys.platform == 'win32':
                si = subprocess.STARTUPINFO()
                si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                si.wShowWindow = subprocess.SW_HIDE
                hide_kwargs = {'startupinfo': si, 'creationflags': subprocess.CREATE_NO_WINDOW}

            images = convert_from_path(pdf_file, **hide_kwargs)
            base_name = Path(pdf_file).stem
            
            for i, img in enumerate(images):
                output_path = os.path.join(output_dir, f"{base_name}_page_{i+1}.png")
                img.save(output_path, 'PNG')
            
            self.status_label.setText(f"Saved to: {output_dir}")
            QMessageBox.information(self, "Success", f"Extracted {len(images)} pages!")
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))
    
    def word_to_pdf(self):
        word_file, _ = QFileDialog.getOpenFileName(self, "Select Word File", "", "Word Files (*.docx)")
        if not word_file:
            return
        
        try:
            doc = Document(word_file)
            output_file = word_file.replace('.docx', '.pdf')
            
            c = canvas.Canvas(output_file, pagesize=letter)
            y = 750
            
            for para in doc.paragraphs:
                if y < 50:
                    c.showPage()
                    y = 750
                c.drawString(50, y, para.text[:90])
                y -= 20
            
            c.save()
            self.status_label.setText(f"Saved: {output_file}")
            QMessageBox.information(self, "Success", "Word converted to PDF!")
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))
    
    def pdf_to_word(self):
        pdf_file, _ = QFileDialog.getOpenFileName(self, "Select PDF", "", "PDF Files (*.pdf)")
        if not pdf_file:
            return
        
        try:
            reader = PdfReader(pdf_file)
            doc = Document()
            doc.add_heading('Converted from PDF', 0)
            
            for page in reader.pages:
                text = page.extract_text()
                doc.add_paragraph(text)
            
            output_file = pdf_file.replace('.pdf', '.docx')
            doc.save(output_file)
            
            self.status_label.setText(f"Saved: {output_file}")
            QMessageBox.information(self, "Success", "PDF converted to Word!")
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))
    
    def excel_to_pdf(self):
        excel_file, _ = QFileDialog.getOpenFileName(self, "Select Excel File", "", "Excel Files (*.xlsx *.xls)")
        if not excel_file:
            return
        
        try:
            wb = load_workbook(excel_file)
            ws = wb.active
            
            output_file = excel_file.replace('.xlsx', '.pdf').replace('.xls', '.pdf')
            c = canvas.Canvas(output_file, pagesize=letter)
            y = 750
            
            for row in ws.iter_rows(values_only=True):
                if y < 50:
                    c.showPage()
                    y = 750
                row_text = ' | '.join([str(cell) if cell else '' for cell in row])
                c.drawString(50, y, row_text[:80])
                y -= 20
            
            c.save()
            self.status_label.setText(f"Saved: {output_file}")
            QMessageBox.information(self, "Success", "Excel converted to PDF!")
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))
    
    def pdf_to_excel(self):
        pdf_file, _ = QFileDialog.getOpenFileName(self, "Select PDF", "", "PDF Files (*.pdf)")
        if not pdf_file:
            return
        
        try:
            reader = PdfReader(pdf_file)
            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = "PDF Content"
            
            row_num = 1
            for page in reader.pages:
                text = page.extract_text()
                for line in text.split('\n'):
                    ws.cell(row=row_num, column=1, value=line)
                    row_num += 1
            
            output_file = pdf_file.replace('.pdf', '.xlsx')
            wb.save(output_file)
            
            self.status_label.setText(f"Saved: {output_file}")
            QMessageBox.information(self, "Success", "PDF converted to Excel!")
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))
    
    def txt_to_pdf(self):
        txt_file, _ = QFileDialog.getOpenFileName(self, "Select TXT File", "", "Text Files (*.txt)")
        if not txt_file:
            return
        
        try:
            with open(txt_file, 'r', encoding='utf-8') as f:
                text = f.read()
            
            output_file = txt_file.replace('.txt', '.pdf')
            c = canvas.Canvas(output_file, pagesize=letter)
            y = 750
            
            for line in text.split('\n'):
                if y < 50:
                    c.showPage()
                    y = 750
                c.drawString(50, y, line[:90])
                y -= 15
            
            c.save()
            self.status_label.setText(f"Saved: {output_file}")
            QMessageBox.information(self, "Success", "TXT converted to PDF!")
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))
    
    def md_to_pdf(self):
        md_file, _ = QFileDialog.getOpenFileName(self, "Select Markdown File", "", "Markdown Files (*.md)")
        if not md_file:
            return
        
        try:
            with open(md_file, 'r', encoding='utf-8') as f:
                md_text = f.read()
            
            html = markdown.markdown(md_text)
            
            output_file = md_file.replace('.md', '.pdf')
            c = canvas.Canvas(output_file, pagesize=letter)
            y = 750
            
            text = re.sub('<[^<]+?>', '', html)
            
            for line in text.split('\n'):
                if y < 50:
                    c.showPage()
                    y = 750
                if line.strip():
                    c.drawString(50, y, line[:90])
                    y -= 15
            
            c.save()
            self.status_label.setText(f"Saved: {output_file}")
            QMessageBox.information(self, "Success", "Markdown converted to PDF!")
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))
    
    # Merge/Split Methods
    
    def add_pdfs_to_merge(self):
        files, _ = QFileDialog.getOpenFileNames(self, "Select PDFs", "", "PDF Files (*.pdf)")
        for f in files:
            self.merge_list.addItem(f)
    
    def merge_pdfs(self):
        if self.merge_list.count() == 0:
            QMessageBox.warning(self, "Warning", "No PDFs selected!")
            return
        
        output, _ = QFileDialog.getSaveFileName(self, "Save Merged PDF", "", "PDF Files (*.pdf)")
        if not output:
            return
        
        try:
            writer = PdfWriter()
            for i in range(self.merge_list.count()):
                reader = PdfReader(self.merge_list.item(i).text())
                for page in reader.pages:
                    writer.add_page(page)
            
            with open(output, 'wb') as f:
                writer.write(f)
            
            self.status_label.setText(f"Saved: {output}")
            QMessageBox.information(self, "Success", f"Merged {self.merge_list.count()} PDFs!")
            self.merge_list.clear()
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))
    
    def split_pdf_all(self):
        pdf_file, _ = QFileDialog.getOpenFileName(self, "Select PDF to Split", "", "PDF Files (*.pdf)")
        if not pdf_file:
            return
        
        output_dir = QFileDialog.getExistingDirectory(self, "Select Output Directory")
        if not output_dir:
            return
        
        try:
            reader = PdfReader(pdf_file)
            base_name = Path(pdf_file).stem
            
            for i, page in enumerate(reader.pages):
                writer = PdfWriter()
                writer.add_page(page)
                
                output_path = os.path.join(output_dir, f"{base_name}_page_{i+1}.pdf")
                with open(output_path, 'wb') as f:
                    writer.write(f)
            
            self.status_label.setText(f"Saved to: {output_dir}")
            QMessageBox.information(self, "Success", f"Split into {len(reader.pages)} pages!")
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))
    
    def split_pdf_range(self):
        pdf_file, _ = QFileDialog.getOpenFileName(self, "Select PDF to Split", "", "PDF Files (*.pdf)")
        if not pdf_file:
            return
        
        reader = PdfReader(pdf_file)
        total_pages = len(reader.pages)
        
        range_text, ok = QInputDialog.getText(
            self, "Page Range", 
            f"Enter page range (e.g., 1-5)\nTotal pages: {total_pages}"
        )
        
        if not ok or not range_text:
            return
        
        try:
            start, end = map(int, range_text.split('-'))
            start -= 1
            
            output_file, _ = QFileDialog.getSaveFileName(self, "Save Split PDF", "", "PDF Files (*.pdf)")
            if not output_file:
                return
            
            writer = PdfWriter()
            for i in range(start, min(end, total_pages)):
                writer.add_page(reader.pages[i])
            
            with open(output_file, 'wb') as f:
                writer.write(f)
            
            self.status_label.setText(f"Saved: {output_file}")
            QMessageBox.information(self, "Success", "PDF split successfully!")
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))
    
    # Security Methods
    
    def protect_pdf(self):
        pdf_file, _ = QFileDialog.getOpenFileName(self, "Select PDF to Protect", "", "PDF Files (*.pdf)")
        if not pdf_file:
            return
        
        password = self.password_input.text()
        if not password:
            QMessageBox.warning(self, "Warning", "Please enter a password!")
            return
        
        try:
            reader = PdfReader(pdf_file)
            writer = PdfWriter()
            
            for page in reader.pages:
                writer.add_page(page)
            
            writer.encrypt(password)
            
            output_file = pdf_file.replace('.pdf', '_protected.pdf')
            with open(output_file, 'wb') as f:
                writer.write(f)
            
            self.status_label.setText(f"Saved: {output_file}")
            QMessageBox.information(self, "Success", "PDF protected!")
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))
    
    def unlock_pdf(self):
        pdf_file, _ = QFileDialog.getOpenFileName(self, "Select PDF to Unlock", "", "PDF Files (*.pdf)")
        if not pdf_file:
            return
        
        password = self.unlock_password_input.text()
        if not password:
            QMessageBox.warning(self, "Warning", "Please enter the password!")
            return
        
        try:
            reader = PdfReader(pdf_file)
            
            if reader.is_encrypted:
                reader.decrypt(password)
            
            writer = PdfWriter()
            for page in reader.pages:
                writer.add_page(page)
            
            output_file = pdf_file.replace('.pdf', '_unlocked.pdf')
            with open(output_file, 'wb') as f:
                writer.write(f)
            
            self.status_label.setText(f"Saved: {output_file}")
            QMessageBox.information(self, "Success", "PDF unlocked!")
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))
    
    def compress_pdf(self):
        """Compress PDF with selected compression level using Ghostscript"""
        pdf_file, _ = QFileDialog.getOpenFileName(self, "Select PDF to Compress", "", "PDF Files (*.pdf)")
        if not pdf_file:
            return
        
        try:
            # Get compression level
            level_idx = self.compression_level.currentIndex()
            
            # Save compressed PDF
            output_file = pdf_file.replace('.pdf', '_compressed.pdf')
            
            # Check if output file exists
            if os.path.exists(output_file):
                reply = QMessageBox.question(
                    self,
                    "Overwrite File?",
                    f"{output_file} already exists.\n\nOverwrite?",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
                )
                if reply != QMessageBox.StandardButton.Yes:
                    return
            
            # Configure Ghostscript compression settings based on level
            if level_idx == 0:  # Low compression
                quality_setting = "/printer"  # High quality
            elif level_idx == 1:  # Medium compression (recommended)
                quality_setting = "/ebook"  # Balanced
            else:  # High compression (level_idx == 2)
                quality_setting = "/screen"  # Maximum compression
            
            # Try to find Ghostscript
            gs_command = None
            possible_gs_paths = [
                "gswin64c.exe",  # Windows 64-bit
                "gswin32c.exe",  # Windows 32-bit
                "gs",  # Linux/Mac
                r"C:\Program Files\gs\gs10.04.0\bin\gswin64c.exe",
                r"C:\Program Files\gs\gs10.03.1\bin\gswin64c.exe",
                r"C:\Program Files\gs\gs10.03.0\bin\gswin64c.exe",
                r"C:\Program Files\gs\gs10.02.1\bin\gswin64c.exe",
                r"C:\Program Files\gs\gs10.02.0\bin\gswin64c.exe",
                r"C:\Program Files\gs\gs10.01.2\bin\gswin64c.exe",
                r"C:\Program Files\gs\gs10.01.1\bin\gswin64c.exe",
                r"C:\Program Files\gs\gs10.01.0\bin\gswin64c.exe",
                r"C:\Program Files\gs\gs10.00.0\bin\gswin64c.exe",
                r"C:\Program Files (x86)\gs\gs10.04.0\bin\gswin32c.exe",
                r"C:\Program Files (x86)\gs\gs10.03.1\bin\gswin32c.exe",
                r"C:\Program Files (x86)\gs\gs10.03.0\bin\gswin32c.exe",
            ]
            
            # Check PATH first
            import shutil
            for cmd in ["gswin64c.exe", "gswin32c.exe", "gs"]:
                if shutil.which(cmd):
                    gs_command = cmd
                    break
            
            # Check specific paths if not in PATH
            if not gs_command:
                for path in possible_gs_paths:
                    if os.path.exists(path):
                        gs_command = path
                        break
            
            if not gs_command:
                # Ghostscript not found - show installation instructions
                QMessageBox.critical(
                    self,
                    "Ghostscript Required",
                    "Ghostscript is required for PDF compression but was not found.\n\n"
                    "Please install Ghostscript:\n"
                    "Windows: Download from https://ghostscript.com/releases/gsdnld.html\n"
                    "Linux: sudo apt install ghostscript\n"
                    "Mac: brew install ghostscript"
                )
                return
            
            # Build Ghostscript command
            import subprocess
            gs_cmd = [
                gs_command,
                "-sDEVICE=pdfwrite",
                "-dCompatibilityLevel=1.4",
                f"-dPDFSETTINGS={quality_setting}",
                "-dNOPAUSE",
                "-dQUIET",
                "-dBATCH",
                f"-sOutputFile={output_file}",
                pdf_file
            ]
            
            # Run Ghostscript
            # Prevent console window from appearing on Windows
            startupinfo = None
            creationflags = 0
            
            if sys.platform == 'win32':
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                startupinfo.wShowWindow = subprocess.SW_HIDE
                creationflags = subprocess.CREATE_NO_WINDOW
            
            result = subprocess.run(
                gs_cmd, 
                capture_output=True, 
                text=True,
                startupinfo=startupinfo,
                creationflags=creationflags
            )
            
            if result.returncode != 0:
                raise Exception(f"Ghostscript failed: {result.stderr}")
            
            # Get file sizes for comparison
            original_size = os.path.getsize(pdf_file)
            compressed_size = os.path.getsize(output_file)
            
            if compressed_size >= original_size:
                reduction = 0
            else:
                reduction = ((original_size - compressed_size) / original_size) * 100
            
            original_mb = original_size / (1024 * 1024)
            compressed_mb = compressed_size / (1024 * 1024)
            
            self.status_label.setText(f"Saved: {output_file} ({reduction:.1f}% reduction)")
            
            if reduction > 0:
                QMessageBox.information(
                    self, 
                    "Success", 
                    f"PDF compressed successfully!\n\n"
                    f"Original: {original_mb:.2f} MB\n"
                    f"Compressed: {compressed_mb:.2f} MB\n"
                    f"Reduction: {reduction:.1f}%"
                )
            else:
                QMessageBox.information(
                    self, 
                    "Success", 
                    f"PDF processed successfully!\n\n"
                    f"Original: {original_mb:.2f} MB\n"
                    f"Output: {compressed_mb:.2f} MB\n\n"
                    f"Note: This PDF may already be well-optimized.\n"
                    f"No significant size reduction achieved."
                )
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Compression failed: {str(e)}")
    
    # OCR Methods
    
    def ocr_image(self):
        if not pytesseract:
            QMessageBox.critical(self, "Error",
                "pytesseract is not installed.\nRun: pip install pytesseract")
            return

        # Try to locate the Tesseract binary
        import shutil
        tesseract_cmd = None
        candidates = [
            r"C:\Program Files\Tesseract-OCR\tesseract.exe",
            r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
            "tesseract",
        ]
        for c in candidates:
            if os.path.exists(c) or shutil.which(c):
                tesseract_cmd = c
                break

        if not tesseract_cmd:
            QMessageBox.critical(self, "Tesseract Not Found",
                "The Tesseract OCR binary is not installed or not in PATH.\n\n"
                "Download it from:\n"
                "https://github.com/UB-Mannheim/tesseract/wiki\n\n"
                "Install it, then restart PDF of Death.")
            return

        pytesseract.pytesseract.tesseract_cmd = tesseract_cmd

        image_file, _ = QFileDialog.getOpenFileName(
            self, "Select Image", "", 
            "Images (*.png *.jpg *.jpeg *.bmp *.tiff)"
        )
        if not image_file:
            return
        
        try:
            img = Image.open(image_file)
            text = pytesseract.image_to_string(img)
            self.ocr_output.setPlainText(text)
            QMessageBox.information(self, "Success", "Text extracted!")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"OCR failed: {str(e)}")
    
    def ocr_pdf(self):
        if not pytesseract:
            QMessageBox.critical(self, "Error",
                "pytesseract is not installed.\nRun: pip install pytesseract")
            return

        # Locate Tesseract binary
        import shutil
        tesseract_cmd = None
        for c in [r"C:\Program Files\Tesseract-OCR\tesseract.exe",
                  r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
                  "tesseract"]:
            if os.path.exists(c) or shutil.which(c):
                tesseract_cmd = c
                break

        if not tesseract_cmd:
            QMessageBox.critical(self, "Tesseract Not Found",
                "The Tesseract OCR binary is not installed or not in PATH.\n\n"
                "Download it from:\n"
                "https://github.com/UB-Mannheim/tesseract/wiki\n\n"
                "Install it, then restart PDF of Death.")
            return

        pytesseract.pytesseract.tesseract_cmd = tesseract_cmd

        # Locate bundled Poppler (works for both dev and PyInstaller)
        if getattr(sys, 'frozen', False):
            poppler_path = Path(sys.executable).parent / "poppler"
        else:
            poppler_path = Path(__file__).parent / "poppler"
        poppler_path = str(poppler_path) if poppler_path.exists() else None

        pdf_file, _ = QFileDialog.getOpenFileName(self, "Select PDF", "", "PDF Files (*.pdf)")
        if not pdf_file:
            return

        try:
            try:
                from pdf2image import convert_from_path
                has_pdf2image = True
            except ImportError:
                has_pdf2image = False

            if has_pdf2image:
                # True OCR: render each page as an image, then run Tesseract
                self.status_label.setText("Converting PDF pages to images...")
                QApplication.processEvents()

                # Suppress console window on Windows
                hide_kwargs = {}
                if sys.platform == 'win32':
                    si = subprocess.STARTUPINFO()
                    si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                    si.wShowWindow = subprocess.SW_HIDE
                    hide_kwargs = {'startupinfo': si, 'creationflags': subprocess.CREATE_NO_WINDOW}

                pages = convert_from_path(pdf_file, dpi=300, poppler_path=poppler_path,
                                          use_pdftocairo=False, **hide_kwargs)
                all_text = ""
                for i, page_img in enumerate(pages):
                    self.status_label.setText(f"OCR processing page {i + 1} of {len(pages)}...")
                    QApplication.processEvents()
                    all_text += pytesseract.image_to_string(page_img) + "\n\n"

                self.ocr_output.setPlainText(all_text.strip())
                self.status_label.setText(f"OCR complete: {len(pages)} pages")
                QMessageBox.information(self, "Success",
                    f"Extracted text from {len(pages)} pages using OCR!")
            else:
                # Fallback: extract embedded text only (won't work for scanned PDFs)
                reader = PdfReader(pdf_file)
                text = ""
                for page in reader.pages:
                    extracted = page.extract_text()
                    if extracted:
                        text += extracted + "\n\n"
                if text.strip():
                    self.ocr_output.setPlainText(text.strip())
                    QMessageBox.information(self, "Success",
                        f"Extracted embedded text from {len(reader.pages)} pages.\n\n"
                        "Note: For scanned PDFs, install pdf2image for full OCR:\n"
                        "pip install pdf2image")
                else:
                    QMessageBox.warning(self, "No Text Found",
                        "No embedded text found in this PDF.\n\n"
                        "This may be a scanned PDF. Install pdf2image for full OCR:\n"
                        "pip install pdf2image\n\n"
                        "Also requires Poppler:\n"
                        "https://github.com/oschwartz10612/poppler-windows/releases")

        except Exception as e:
            QMessageBox.critical(self, "Error", f"OCR PDF failed: {str(e)}")
    
    def save_extracted_text(self):
        text = self.ocr_output.toPlainText()
        if not text:
            QMessageBox.warning(self, "Warning", "No text to save!")
            return
        
        output_file, _ = QFileDialog.getSaveFileName(self, "Save Text", "", "Text Files (*.txt)")
        if not output_file:
            return
        
        if os.path.exists(output_file):
            reply = QMessageBox.question(
                self,
                "Overwrite File?",
                f"{output_file} already exists.\n\nOverwrite?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if reply != QMessageBox.StandardButton.Yes:
                return

        try:
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(text)

            self.status_label.setText(f"Saved: {output_file}")
            QMessageBox.information(self, "Success", "Text saved!")

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    
    # Create PDF Methods
    
    def create_pdf_from_text(self):
        text = self.create_text.toPlainText()
        if not text:
            QMessageBox.warning(self, "Warning", "Please enter some text!")
            return
        
        output_file, _ = QFileDialog.getSaveFileName(self, "Save PDF", "", "PDF Files (*.pdf)")
        if not output_file:
            return
        
        try:
            c = canvas.Canvas(output_file, pagesize=letter)
            y = 750
            
            for line in text.split('\n'):
                if y < 50:
                    c.showPage()
                    y = 750
                c.drawString(50, y, line[:90])
                y -= 15
            
            c.save()
            self.status_label.setText(f"Saved: {output_file}")
            QMessageBox.information(self, "Success", "PDF created!")
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))
    
    # Text Convert Methods
    
    def convert_text_file(self):
        input_file, _ = QFileDialog.getOpenFileName(
            self, "Select File to Convert", "", "All Files (*)"
        )
        if not input_file:
            return

        from_fmt = self.from_format.currentText()
        to_fmt = self.to_format.currentText()

        if from_fmt == to_fmt:
            QMessageBox.warning(self, "Warning", "Source and target formats are the same!")
            return

        output_file = input_file.rsplit('.', 1)[0] + f'.{to_fmt.lower()}'

        # ✅ OVERWRITE CHECK — OUTSIDE try
        if os.path.exists(output_file):
            reply = QMessageBox.question(
                self,
                "Overwrite File?",
                f"{output_file} already exists.\n\nOverwrite?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if reply != QMessageBox.StandardButton.Yes:
                return

        try:
            with open(input_file, 'r', encoding='utf-8') as f:
                content = f.read()

            converted = content

            if from_fmt == "MD" and to_fmt == "HTML":
                converted = markdown.markdown(content)

            elif from_fmt == "HTML" and to_fmt == "TXT":
                converted = re.sub('<[^<]+?>', '', content)

            elif from_fmt == "CSV" and to_fmt == "JSON":
                import csv, json
                reader = csv.DictReader(content.splitlines())
                converted = json.dumps(list(reader), indent=2)

            elif from_fmt == "JSON" and to_fmt == "CSV":
                import json, csv, io
                data = json.loads(content)
                if isinstance(data, list) and data:
                    buf = io.StringIO()
                    writer = csv.DictWriter(buf, fieldnames=data[0].keys())
                    writer.writeheader()
                    writer.writerows(data)
                    converted = buf.getvalue()

            elif from_fmt == "TXT" and to_fmt == "JSON":
                import json
                lines = [l for l in content.splitlines() if l.strip()]
                converted = json.dumps({"lines": lines}, indent=2)

            elif from_fmt == "TXT" and to_fmt == "XML":
                lines = [l for l in content.splitlines() if l.strip()]
                xml_lines = ["<?xml version=\"1.0\" encoding=\"UTF-8\"?>", "<document>"]
                for line in lines:
                    escaped = line.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                    xml_lines.append(f"  <line>{escaped}</line>")
                xml_lines.append("</document>")
                converted = "\n".join(xml_lines)

            elif from_fmt == "TXT" and to_fmt == "HTML":
                lines = [l for l in content.splitlines()]
                html_lines = ["<!DOCTYPE html>", "<html>", "<body>"]
                for line in lines:
                    escaped = line.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                    html_lines.append(f"  <p>{escaped}</p>" if escaped else "  <br>")
                html_lines.extend(["</body>", "</html>"])
                converted = "\n".join(html_lines)

            elif from_fmt == "TXT" and to_fmt == "MD":
                lines = content.splitlines()
                converted = "\n".join(f"{line}" for line in lines)

            elif from_fmt == "TXT" and to_fmt == "CSV":
                import csv, io
                lines = [l for l in content.splitlines() if l.strip()]
                buf = io.StringIO()
                writer = csv.writer(buf)
                for line in lines:
                    writer.writerow([line])
                converted = buf.getvalue()

            elif from_fmt == "XML" and to_fmt == "TXT":
                converted = re.sub('<[^<]+?>', '', content).strip()

            elif from_fmt == "JSON" and to_fmt == "TXT":
                import json
                data = json.loads(content)
                converted = json.dumps(data, indent=2)

            elif from_fmt == "HTML" and to_fmt == "MD":
                converted = re.sub('<[^<]+?>', '', content).strip()

            elif from_fmt == "MD" and to_fmt == "TXT":
                converted = re.sub(r'[#*`_>\-\[\]()!]', '', content).strip()

            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(converted)

            self.status_label.setText(f"Saved: {output_file}")
            QMessageBox.information(
                self, "Success", f"Converted {from_fmt} to {to_fmt}!"
            )

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))




def main():
    # Fix for Windows taskbar icon
    if sys.platform == 'win32':
        import ctypes
        myappid = 'deathsheadsoftware.pdfofdeath.1.0'  # arbitrary string
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(myappid)
    
    app = QApplication(sys.argv)
    
    # Set application icon - works for both dev and PyInstaller
    if getattr(sys, 'frozen', False):
        # Running as compiled executable
        icon_path = Path(sys._MEIPASS) / "icon.ico"
    else:
        # Running as script
        icon_path = Path(__file__).parent / "icon.ico"
    
    if icon_path.exists():
        app.setWindowIcon(QIcon(str(icon_path)))
    
    splash = create_splash()
    if splash:
        splash.show()
        app.processEvents()
        for msg in ["Starting PDF of Death...", "Loading tools...", "Almost Ready!"]:
            splash.showMessage("\n\n\n\n\n\n\n" + msg, 
                             Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignCenter, 
                             QColor(255, 255, 255))
            app.processEvents()
            time.sleep(0.3)
    
    window = PDFEditorApp()
    window.show()
    
    if splash:
        splash.finish(window)
    
    sys.exit(app.exec())


if __name__ == '__main__':
    main()
