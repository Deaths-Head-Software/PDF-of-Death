When loading PDF's underlined text will not be displayed.
The underlines can be added back in the app itself.